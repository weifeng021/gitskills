package com.selenium.method;

import org.checkerframework.checker.nullness.qual.Nullable;
import org.jetbrains.annotations.NotNull;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;


public class WebDriverUtil {

    private static WebDriver driver;

    public static WebDriver getDriver() {
        System.setProperty("webdriver.gecko.driver", "C:\\Users\\v-fewei\\Downloads\\geckodriver-v0.27.0-win64\\geckodriver.exe");//浏览器驱动路径
        if (driver == null) {
            driver = new FirefoxDriver();
        }
        return driver;
    }

    public static boolean isElementPresent(WebDriver driver, final By by, int timeout) {
/*        WebDriverWait webDriverWait = new WebDriverWait(driver, timeout);
        boolean isPresent = false;
        isPresent = webDriverWait.until(new ExpectedCondition<WebElement>() {
            @Override
            public WebElement apply(WebDriver driver) {
                return driver.findElement(by);
            }
        }).isDisplayed();*/
        boolean isPresent = false;
        try {
            Thread.sleep(timeout * 1000);
            List<WebElement> elements = driver.findElements(by);
            if (elements.size() != 0) {
                isPresent=true;
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return isPresent;
    }
}