package com.selenium.method;

import com.sun.java.swing.plaf.windows.resources.windows;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public class SeleniumMethod {


    public static void main(String args[]) {

        WebDriver driver = WebDriverUtil.getDriver();
       // Browser(driver);
        try {
            FileUpload(driver);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //OpenNewBrower(driver);
        //ChangeBrower(driver);
    /*    try {
            Html5VedioTest(driver);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }*/

     /*   try {
            Html5CanvasTest(driver);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }*/
    }
//改变窗口大小
    public static void Browser(WebDriver driver) {

        driver.manage().window().maximize();
        //页面加载超时时间设置为 10s
        driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
        driver.get("https://www.baidu.com/");
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        driver.manage().window().setSize(new Dimension(720, 360));
        driver.quit();
    }
    //登录 Beyondsoft//浏览器操作
    public static void BeyondsoftLogin(WebDriver driver){
        
        driver.get("https://e-cology.beyondsoft.com/login/Login.jsp?logintype=1");
        //定位对象给定 30s 的时间,如果 30s 内没有定位到则抛出异常
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        driver.findElement(By.id("loginid")).clear();
        WebElement element=driver.findElement(By.id("loginid"));
        element.sendKeys("weifeng022");
        element.sendKeys(Keys.BACK_SPACE);
        driver.findElement(By.id("passwords")).clear();
        driver.findElement(By.id("passwords")).sendKeys("WFwf.20200326!");
        driver.findElement(By.id("BtnLogin")).click();
        driver.quit();
    }
   //获取截图
    public static void GetImage(WebDriver driver) {

        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        driver.get("https://www.baidu.com/");
        File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        try {
            FileUtils.copyFile(screenshotFile, new File("C:\\Users\\v-fewei\\screenshot.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        driver.quit();
    }
    //鼠标操作
    public static void MouseOperation(WebDriver driver){
        //鼠标悬浮操作
        Actions actions = new Actions(driver);
        actions.clickAndHold(driver.findElement(By.id("s-usersetting-top"))).perform();
        try {
            Thread.sleep(5000L);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        driver.findElement(By.partialLinkText("高级搜索")).click();

        //鼠标双击指定的元素
        actions.doubleClick(driver.findElement(By.id("su"))).perform();
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        //鼠标拖拽动作，将 search_setting 元素拖放到 search_text 元素的位置
        WebElement search_text = driver.findElement(By.id("kw"));
        WebElement search_setting2 = driver.findElement(By.linkText("设置"));
        actions.dragAndDrop(search_setting2, search_text).perform();
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

        //释放鼠标
        actions.release().perform();
    }

    //键盘操作
    public static void KeyBordOperation(WebDriver driver) throws InterruptedException {

        WebElement input = driver.findElement(By.id("kw"));

        //输入数据
        input.sendKeys("Seleniumm");
        Thread.sleep(2000);

        //按下键盘删除键，删除一个数据
        input.sendKeys(Keys.BACK_SPACE);
        Thread.sleep(2000);

        //按下空格建
        input.sendKeys(Keys.SPACE);
        input.sendKeys("+java");
        Thread.sleep(2000);

        //模拟 Ctrl + a ,全选
        input.sendKeys(Keys.CONTROL, "a");
        Thread.sleep(2000);

        //模拟 Ctrl + x ,剪切
        input.sendKeys(Keys.CONTROL, "x");
        Thread.sleep(2000);

        //模拟 Ctrl + v ,粘贴
        input.sendKeys(Keys.CONTROL, "v");
        Thread.sleep(2000);

        //模拟回车键
        input.sendKeys(Keys.ENTER);
        Thread.sleep(2000);
        driver.quit();
    }

    //获取页面元素
    private static void Assert(WebDriver driver) throws InterruptedException {

        //获取当前的 title 和 url
        System.out.printf("title of current page is %s\n", driver.getTitle());
        System.out.printf("url of current page is %s\n", driver.getCurrentUrl());

        //百度搜索
        WebElement search = driver.findElement(By.id("kw"));
        search.sendKeys("Selenium");
        search.sendKeys(Keys.ENTER);
        Thread.sleep(2000);

        System.out.println("======== After search ========");

        //获取当前的 title 和 url 看看
        System.out.printf("title of current page is %s\n", driver.getTitle());
        System.out.printf("url of current page is %s\n", driver.getCurrentUrl());
        Thread.sleep(2000);

        //获取第一条搜索结果的标题
        WebElement result = driver.findElement(By.xpath("//*[@id=\"1\"]/h3/a"));
        System.out.println(result.getText());
        Thread.sleep(2000);

        driver.quit();
    }
    //设置页面元素等待
    private static void ElementWait(WebDriver driver) throws InterruptedException{

        //显示等待，针对某个元素
        /**
         * WebDriverWait(driver, 10, 1)
         * driver： 浏览器驱动。 10： 最长超时时间， 默认以秒为单位。 1： 检测的的间隔（步长） 时间， 默认为 0.5s
         */
        WebDriverWait wait=new WebDriverWait(driver,10,1);
        wait.until(new ExpectedCondition<WebElement>() {
            @Override
            public WebElement apply(WebDriver webDriver) {
                return webDriver.findElement(By.id("kw"));
            }
        }).sendKeys("Selenium");

        driver.findElement(By.id("su")).click();
        Thread.sleep(2000);
    }

    private static void ElementsPositioning(WebDriver driver) throws InterruptedException {

        WebElement search_text = driver.findElement(By.id("kw"));
        search_text.sendKeys("Selenium");
        search_text.submit();
        Thread.sleep(2000);

        /**
         * 通过 xpath ,我们找到匹配到的第一页搜索结果 循环打印
         * 这里打印的是第一页搜索的搜索结果，因为搜索结果展示都可以通过 //div/div/h3 定位到
         */
        List<WebElement> search_result = driver.findElements(By.xpath("//div/div/h3"));

        //打印元素的个数
        System.out.println(search_result.size());

        //循环打印搜索结果的标题
        for (WebElement result : search_result) {
            System.out.println(result.getText());
        }

        System.out.println("-------- *..* --------");

        //打印第 n 结果的标题
        WebElement text = search_result.get(search_result.size() - 10);
        System.out.println(text.getText());

        driver.quit();
    }
    //多表单切换
    /**
     * WebDriver 只能在一个页面上对元素识别与定位,但是对于 frame/iframe 表单内嵌页面上的元素无法直接定位
     * 这时就需要通过 switchTo().frame()方法将当前定 位的主体切换为 frame/iframe 表单的内嵌页面中
     * iframe 基本已经被h5淘汰,不过我们还是要了解一下,以126邮箱登录为例
     */
    private static void SwitchTable(WebDriver driver) {

        driver.get("http://www.126.com");

        //这里等待 5s ,因为 iframe 的创建比其它包括 scripts 和 css 的 DOM 元素的创建要慢 1-2 个数量级
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        WebElement frame = driver.findElement(By.xpath("//*[@id='loginDiv']/iframe"));
        driver.switchTo().frame(frame);    //switchTo 还可以切换到弹出框等

        driver.findElement(By.name("email")).clear();
        driver.findElement(By.name("email")).sendKeys("username");
        driver.findElement(By.name("password")).clear();
        driver.findElement(By.name("password")).sendKeys("password");
        driver.findElement(By.id("dologin")).click();

        //切换回默认页面
        driver.switchTo().defaultContent();
    }

    //下拉框选择
    /**
     * WebDriver提供了 Select 类来处理下拉框
     * Select类用于定位<select>标签。selectByValue()方法符用于选取<option>标签的value值
     */
    private static void SelectWindow(WebDriver driver) throws InterruptedException {

        //以百度搜索设置页面的下拉框为例
        driver.findElement(By.linkText("设置")).click();
        driver.findElement(By.linkText("搜索设置")).click();
        Thread.sleep(2000);

        //<select>标签的下拉框选择
        WebElement el = driver.findElement(By.xpath("//select"));
        Select sel = new Select(el);
        sel.selectByValue("20");
        Thread.sleep(2000);

        driver.quit();
    }


    //警告框处理
    /**
     * 在WebDriver中处理JavaScript所生成的alert、confirm以及prompt
     * 1. 使用switchTo().alert()方法定位到alert/confirm/prompt
     * 2. 使用text/accept/dismiss/sendKeys等方法进行操作
     * -----------------------------------------------
     * getText()： 返回 alert/confirm/prompt 中的文字信息
     * accept()： 接受现有警告框
     * dismiss()： 解散现有警告框
     * sendKeys(keysToSend)： 发送文本至警告框
     * keysToSend： 将文本发送至警告框
     */
    private static void AlertDemo(WebDriver driver) throws InterruptedException {

        //类似百度设置的弹出框是不能通过前端工具对其进行定位的，这时候就要用到switchTo().alert()了
        driver.findElement(By.linkText("设置")).click();
        driver.findElement(By.linkText("搜索设置")).click();
        Thread.sleep(2000);

        //点击保存设置
        driver.findElement(By.linkText("保存设置")).click();

        System.out.println(driver.switchTo().alert().getText());

        //接收弹框
        driver.switchTo().alert().accept();
        Thread.sleep(2000);

        driver.quit();
    }


    //文件上传 *

    /**
     * 对于通过input标签实现的上传功能,可以将其看作是一个输入框,可通过sendKeys()指定本地文件路径的方式实现文件上传
     */
    private static void FileUpload(WebDriver driver) throws InterruptedException {

        //找到绝对路径
        File file = new File("./Html/upFile.html");
        String filePath = file.getAbsolutePath();
        driver.get("file://"+filePath);

        //定位上传按钮,添加本地文件
        WebElement element=driver.findElement(By.id("file"));
        Thread.sleep(2000);
        element.sendKeys("C:\\Users\\v-fewei\\upload_file.txt");
        Thread.sleep(2000);

        driver.quit();
    }

    //浏览器Cookie操作

    /**
     * WebDriver操作Cookie相关方法
     * getCookies(): 获得所有cookie信息
     * getCookieNamed(String name): 返回字典的key为"name"的Cookie信息
     * addCookie(cookie dict): 添加Cookie, "cookie dict"指字典对象,必须有 name和 value值
     * deleteCookieNamed(String name): 删除Cookie信息, "name"是要删除的 cookie的名称; "optionsString"是该Cookie 的选项, 目前支持"路径"、"域"
     * deleteAllCookies(): 删除所有的cookie 信息
     */
    private static void BorwserCookie(WebDriver driver) {

        Cookie cookie1 = new Cookie("name", "key-aaaaa");
        Cookie cookie2 = new Cookie("value", "value-bbbbb");
        driver.manage().addCookie(cookie1);
        driver.manage().addCookie(cookie2);
        //获得 Cookie
        Set<Cookie> cookies = driver.manage().getCookies();
        System.out.println(cookies);

        //删除所有 cookie
        //driver.manage().deleteAllCookies();
        driver.quit();
    }


    //调用JavaScript代码

    /**
     * WebDriver提供了 executeScript()方法来执行 JavaScript代码
     * 以调整浏览器滚动条位置为例
     */
    private static void JavaScript(WebDriver driver) throws InterruptedException {

        //设置浏览器窗口大小
        driver.manage().window().setSize(new Dimension(700, 600));
        Thread.sleep(2000);

        //百度搜索
        driver.findElement(By.id("kw")).sendKeys("Selenium");
        driver.findElement(By.id("su")).click();
        Thread.sleep(2000);

        //将页面滚动条拖动
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(100,410)");
        Thread.sleep(200);
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(100,420)");
        Thread.sleep(200);
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(100,430)");
        Thread.sleep(200);
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(100,440)");
        Thread.sleep(200);
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(100,450)");
        Thread.sleep(200);

        driver.quit();
    }

    //多窗口切换
    /**
     * getWindowHandle()： 获得当前窗口句柄
     * getWindowHandles()： 返回的所有窗口的句柄到当前会话
     * switchTo().window()： 用于切换到相应的窗口,与上面的switchTo().frame()类似
     */
    private static void WindowsSwitch(WebDriver driver) throws InterruptedException {

        //获得当前窗口句柄
        String search_handle = driver.getWindowHandle();

        //打开百度注册窗口
        driver.findElement(By.linkText("登录")).click();
        Thread.sleep(2000);
        driver.findElement(By.linkText("立即注册")).click();
        Thread.sleep(2000);

        //获得当前窗口的句柄
        String search_handle_register = driver.getWindowHandle();

        //获取所有窗口句柄
        Set<String> handles = driver.getWindowHandles();

        //判断是否为注册窗口， 并操作注册窗口上的元素
        for (String handle : handles) {
            if (handle.equals(search_handle_register) == false) {
                driver.switchTo().window(handle);
                System.out.println("现在在注册页面");
                Thread.sleep(2000);
                driver.findElement(By.name("userName")).clear();
                driver.findElement(By.name("userName")).sendKeys("用户名");
                driver.findElement(By.name("phone")).clear();
                driver.findElement(By.name("phone")).sendKeys("电话号码");
                //......
                Thread.sleep(2000);
                //关闭当前窗口
                driver.close();
            }
        }
        Thread.sleep(2000);
        driver.quit();
    }

    //Js打开新页面
    public static void OpenNewBrower(WebDriver driver) {

        driver.get("https://www.126.com/");
        JavascriptExecutor js = (JavascriptExecutor) driver;
        String url = "window.open(\"http://www.baidu.com\")";
        js.executeScript(url);

    }
    //浏览器缩放
    public static void ChangeBrower(WebDriver driver) {

        String url="document.getElementsByTagName('body')[0].style.zoom=0.8;";
        ((JavascriptExecutor) driver).executeScript(url);
    }
    //处理Vedio
    private static void Html5VedioTest(WebDriver driver) throws InterruptedException {
        driver.get("http://videojs.com/");
        Thread.sleep(2000);
        //找到vedio元素
        WebElement vedio = driver.findElement(By.id("preview-player_html5_api"));
        //声明Js处理器
        JavascriptExecutor js = (JavascriptExecutor) driver;
        //对vedio这个元素执行播放操作
        js.executeScript("arguments[0].play()", vedio);

        Thread.sleep(5000);
        //对vedio这个元素执行暂停操作
        js.executeScript("arguments[0].pause()", vedio);
        //为了观察效果暂停2秒
        Thread.sleep(2000);
        //对vedio这个元素执行播放操作
        js.executeScript("arguments[0].play()", vedio);
        //为了观察效果暂停2秒
        Thread.sleep(2000);
        //对vedio这个元素执行重新加载视频的操作
        js.executeScript("arguments[0].load()", vedio);
        //为了观察效果暂停2秒
        Thread.sleep(2000);
    }


    private static void Html5CanvasTest(WebDriver driver) throws InterruptedException {
        driver.get("http://literallycanvas.com/");
        Thread.sleep(2000);
        //找到canvas元素
        WebElement canvas = driver.findElement(By.xpath("//*[@id='literally-canvas']//canvas[1]"));
        //声明一个操作类
        Actions drawPen = new Actions(driver);
        //点击并保持不放鼠标 ，按照给定的坐标点移动
        drawPen.clickAndHold(canvas).moveByOffset(20, 100).moveByOffset(100, 20).moveByOffset(-20, -100).moveByOffset(-100, -20).release().perform();
        Thread.sleep(2000);
    }
}