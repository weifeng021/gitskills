package com.upload;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.By;
import java.io.File;

public class UpFile {

    public static void main(String[] args){
        System.setProperty("webdriver.gecko.driver", "C:\\Users\\v-fewei\\Downloads\\geckodriver-v0.27.0-win64\\geckodriver.exe");//浏览器驱动路径
        WebDriver driver = new FirefoxDriver();
        File file=new File(".\\Html\\upFile.html");
        String filePath=file.getAbsolutePath();
        driver.get(filePath);
        //定位上传按钮， 添加本地文件
        driver.findElement(By.name("file")).sendKeys("C:\\Users\\v-fewei\\upload_file.txt");
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        driver.quit();
    }
}
