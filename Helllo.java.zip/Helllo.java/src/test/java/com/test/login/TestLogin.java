package com.test.login;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class TestLogin {

    public static WebDriver driver;

    @BeforeClass
    public static void beforClass(){
        driver = new FirefoxDriver();
        driver.get("https://e-cology.beyondsoft.com/login/Login.jsp?logintype=1");
    }
    @AfterClass
    public static void afterClass(){
        driver.quit();
    }

    @Test
    public void testLogin(){
        driver.findElement(By.id("loginid")).clear();
        driver.findElement(By.id("loginid")).sendKeys("weifeng02");
        driver.findElement(By.id("passwords")).clear();
        driver.findElement(By.id("passwords")).sendKeys("WFwf.20200326!");
        driver.findElement(By.id("BtnLogin")).click();
    }
}
